# robot-embodiment-survey
Amazon Mechanical Turk Survey for the Robot Embodiment Study
